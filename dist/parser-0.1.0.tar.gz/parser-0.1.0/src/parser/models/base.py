from pydantic import BaseModel


class Base_model(BaseModel):
    pass
